﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "IPush.h"
#include "PushPawnProjectCharacter.h"
#include "MyBotCharacter.generated.h"

UCLASS()
class PUSHPAWNPROJECT_API AMyBotCharacter : public APushPawnProjectCharacter, public IPusherTarget
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<UGameplayAbility> PushAbilityToGrant;

protected:
	//~ Begin IPusherTarget Interface
	virtual void GatherPushOptions(const FPushQuery& PushQuery, FPushOptionBuilder& OptionBuilder) override;
	virtual void CustomizePushEventData(const FGameplayTag& PushEventTag, FGameplayEventData& InOutEventData) override {}
	virtual bool CanPush(const AActor* PusheeActor) const override { return !IsPendingKillPending(); }
	//~ End IPusherTarget Interface
};
