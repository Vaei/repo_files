﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "PushPawnAssetManager.h"

#include "AbilitySystemGlobals.h"

void UPushPawnAssetManager::StartInitialLoading()
{
	Super::StartInitialLoading();

	UAbilitySystemGlobals::Get().InitGlobalData();
}
