﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "MyPlayerCharacter.h"

#include "AbilitySystemComponent.h"


void AMyPlayerCharacter::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);

	AbilitySystemComponent->InitAbilityActorInfo(this, this);
	AbilitySystemComponent->K2_GiveAbility(PushScanAbilityClass);
}
