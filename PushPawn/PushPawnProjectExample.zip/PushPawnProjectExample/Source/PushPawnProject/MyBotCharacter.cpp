﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "MyBotCharacter.h"

#include "PushQuery.h"


void AMyBotCharacter::GatherPushOptions(const FPushQuery& PushQuery, FPushOptionBuilder& OptionBuilder)
{
	if (PushQuery.RequestingAvatar.IsValid())
	{
		FPushOption Push;
		Push.PushAbilityToGrant = PushAbilityToGrant;
		Push.PusheeActorLocation = PushQuery.RequestingAvatar->GetActorLocation();
		Push.PusheeForwardVector = GetActorForwardVector();
		Push.PusherActorLocation = GetActorLocation();
		OptionBuilder.AddPushOption(Push);
	}
}
