// Copyright Epic Games, Inc. All Rights Reserved.

#include "PushPawnProject.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, PushPawnProject, "PushPawnProject" );
 