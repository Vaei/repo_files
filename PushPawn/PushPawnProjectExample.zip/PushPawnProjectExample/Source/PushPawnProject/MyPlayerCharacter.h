﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "IPush.h"
#include "PushPawnProjectCharacter.h"
#include "MyPlayerCharacter.generated.h"

UCLASS()
class PUSHPAWNPROJECT_API AMyPlayerCharacter : public APushPawnProjectCharacter, public IPusheeInstigator
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly) TSubclassOf<UGameplayAbility> PushScanAbilityClass;

	virtual void PossessedBy(AController* NewController) override;

	//~ Begin IPusherTarget Interface
	virtual bool CanBePushed(const AActor* PusherActor) const override { return !IsPendingKillPending(); }
	//~ End IPusherTarget Interface
};
